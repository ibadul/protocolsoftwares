
	window.onload = function () {

	var styles = [ { "stylers": [ { "invert_lightness": true }, { "lightness": 50 }, { "saturation": 50 }, { "hue": "#007fff" }, { "gamma": 0.6 } ] } ]

	var options = {
		mapTypeControlOptions: {
			mapTypeIds: ['Styled']
		},
		center: new google.maps.LatLng(-7.245217594087794, 112.74455556869509),
		
		scrollwheel: false,
		navigationControl: false,
		mapTypeControl: false,
		scaleControl: false,
		draggable: true,
		
		zoom: 16,
		disableDefaultUI: true,	
		mapTypeId: 'Styled'
	};
	var div = document.getElementById('surabaya');
	var map = new google.maps.Map(div, options);
	var styledMapType = new google.maps.StyledMapType(styles, { name: 'Styled' });
	map.mapTypes.set('Styled', styledMapType);
	}