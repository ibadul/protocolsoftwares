/*global $:false */
/*global testData:false */
/*global Modernizr:false */


//###########################			
/*INITIALIZE TIPSY TOOLTIP*/	
//###########################

$(function() {
"use strict";
    $('#example-1').tipsy();
    
    $('#auto-gravity').tipsy({gravity: $.fn.tipsy.autoNS});
	
    $('#foo').tipsy({fade: true, gravity: 's'}); // nw | n | ne | w | e | sw | s | se
	
    $('#fade1').tipsy({fade: true, gravity: 's'});
    $('#fade2').tipsy({fade: true, gravity: 's'});

    
    $('#example-custom-attribute').tipsy({title: 'id'});
    $('#example-callback').tipsy({title: function() { return this.getAttribute('original-title').toUpperCase(); } });
    $('#example-fallback').tipsy({fallback: "Where's my tooltip yo'?" });
    
    $('#example-html').tipsy({html: true });
	
	$('.tooltip').tipsy({fade: true, gravity: 's'});
    
});
  
  
  
  
//################################			
/* INITIALIZE Team CarouFredSel */	
//################################
$(function() {

	$('#carousel').carouFredSel({
		width: '100%',
		items: 4,
		scroll: 1,
		auto: {
			duration: 1250,
			timeoutDuration: 2500
		},
		auto: true,
		prev: '#prev',
		next: '#next',
		pagination: '#pager'
	});

}); 
  
//############################			
/* INITIALIZE Tabs Carousel */	
//############################  
$(function() {
	$('#tabs').carouFredSel({
		circular: false,
		items: 1,
		width: '100%',
		auto: false,
		pagination: {
			container: '#pager2',
			anchorBuilder: function( nr ) {
				return '<a href="#" class="cblines">' + $(this).find('h3').text() + '</a>';
			}
		}
	});
});  
  
  
  
  
// ########################
// BACK TO TOP FUNCTION
// ########################


$(document).ready(function(){
"use strict";
	// hide #back-top first
	$("#back-top").hide();
	
	// fade in #back-top
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 700) {
				$('#back-top').fadeIn();
			} else {
				$('#back-top').fadeOut();
			}
		});

		// scroll body to 0px on click
		$('#back-top a').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 500);
			return false;
		});
		
				// scroll body to 0px on click
		$('#goto a').click(function () {
			$('body,html').animate({
				scrollTop: 600
			}, 500);
			return false;
		});
		
		
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top - 0}, 500);
		});
		
		
		
		
		
	});
});
	
	
	
	
	
// ########################
// Accordion MENU
// ########################


	jQuery(document).ready(function() {
	"use strict";
		// Store variables
		
		var accordion_head = jQuery('.accordion > li > a'),
			accordion_body = jQuery('.accordion li > .sub-menu');

		// Open the first tab on load
		accordion_head.first().addClass('active').next().slideDown('normal');
		
		// Open the second tab on load
		// accordion_head.eq(1).addClass('active').next().slideDown('normal');

		// Click function

		accordion_head.on('click', function(event) {

			// Disable header links
			
			event.preventDefault();

			// Show and hide the tabs on click

			if (jQuery(this).attr('class') !== 'active'){
				accordion_body.slideUp('normal');
				jQuery(this).next().stop(true,true).slideToggle('normal');
				accordion_head.removeClass('active');
				jQuery(this).addClass('active');
			}

		});

	});
	
	
// ########################
// Accordion MENU
// ########################	
	
	jQuery(document).ready(function() {
	"use strict";
		// Store variables
		
		var accordion_head2 = jQuery('.accordion2 > li > a'),
			accordion_body2 = jQuery('.accordion2 li > .sub-menu2');

		// Open the first tab on load
		accordion_head2.first().addClass('active').next().slideDown('normal');
		
		// Open the second tab on load
		// accordion_head.eq(1).addClass('active').next().slideDown('normal');

		// Click function

		accordion_head2.on('click', function(event) {

			// Disable header links
			
			event.preventDefault();

			// Show and hide the tabs on click

			if (jQuery(this).attr('class') !== 'active'){
				accordion_body2.slideUp('normal');
				jQuery(this).next().stop(true,true).slideToggle('normal');
				accordion_head2.removeClass('active');
				jQuery(this).addClass('active');
			}

		});

	});

	
// ############################
// Initialize Masonry
// ############################	
  $(function(){
	
	var $container = $('#container');
	
	$container.masonry({
	  itemSelector: '.box',
	  //columnWidth: 365,
	  isAnimated: !Modernizr.csstransitions
	});
	
	$('#prepend').click(function(){
	  var $boxes = $( boxMaker.makeBoxes() );
	  $container.prepend( $boxes ).masonry( 'reload' );
	});
	
	$('#append').click(function(){
	  var $boxes = $( boxMaker.makeBoxes() );
	  $container.append( $boxes ).masonry( 'appended', $boxes );
	});
	
  });
	
	
	
	
	
	
	
// ############################
// Initialize Elegant Carousel
// ############################
jQuery(document).ready(function() {
	
	$('.carousel').elegantcarousel({
			delay:200,
			fade:300,
			slide:800,
			effect:'slide',		  			//  fade, slide			  
			orientation:'horizontal',		//	horizontal, vertical
			captionFade: 150,
			loop: true,					//	false, true
			autoplay: false,					// 	false, true
			time: 4000,
			stopAutoplay: false
	});
	
	
	// horizontal center of the main  
	function center_main() {
		var window_height = $(window).height();
		var main_height = parseInt($('#main').css('height'));
		var main_height_margin = (window_height - main_height) / 2;
		$('#main').css('top',Math.floor(main_height_margin));
	}
	center_main();
	
});
	
	